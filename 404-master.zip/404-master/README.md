# 404

This 404 page was created for netmagazine.com. 

[Check out the demo](http://hakim.se/experiments/html5/404) or see how it looked in context on [netmagazine.com](http://hakim.se/experiments/html5/404/netmag.html).

# License

MIT licensed

Copyright (C) 2011 Hakim El Hattab, http://hakim.se
